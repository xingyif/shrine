npm-stop(3) -- Stop a package
=============================

## SYNOPSIS

    npm.commands.stop(packages, callback)

## DESCRIPTION

This runs a package's "stop" script, if one was provided.

npm can run stop on multiple packages. Just specify multiple packages
in the `packages` parameter.
